from libreria.archivos import leer_archivo
from libreria.resumen import generar_resumen


def main():
    ruta = input("Ingrese ruta: ")

    contenido = leer_archivo(ruta)

    print(generar_resumen(contenido))


if __name__ == "__main__":
    main()